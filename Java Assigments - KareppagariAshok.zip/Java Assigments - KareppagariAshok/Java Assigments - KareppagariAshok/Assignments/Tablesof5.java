package com.lab5.exercises;

public class Tablesof5 {

	public static void main(String[] args) {
		
		for(int i=1; i<=10; i++)
		{
			System.out.print("5*"+i+"=");
			int res=5*i;
			System.out.println(res);
		}

	}

}
