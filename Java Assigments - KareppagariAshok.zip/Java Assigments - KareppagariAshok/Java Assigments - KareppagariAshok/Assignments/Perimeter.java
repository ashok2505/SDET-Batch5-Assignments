package com.lab1.exercises;

public class Perimeter {

	public static void main(String[] args) {
		
		int length=10;
		int width=5;
		
		int area= 2* length + 2*width;
		
		System.out.println("are of perimeter of Rectangle :"+ area);
		

	}

}
